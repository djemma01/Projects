/**
 * @author 200015143
 * @since   March
 * A program that initialize a movie database  
 */

/**
 * needed libraries
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.*;
import java.util.Scanner;

public class InitializeDB {
    public static void main(String[] args) throws SQLException{
        Scanner reader;
        try {
            /**
             * access file with sql commands that create the needed tabels
             */
            reader = new Scanner(new File("../sqlite.txt"));
        } catch (FileNotFoundException e1) {
            /**
             * prints an appropriate message if the file does not exist
             */
            System.out.println("File not found!");
            return;
        }

        String filename = "Movies.db";
        File file = new File("src/../" + filename);

        /**
         * checks whether the file alredy exist and if so, deletes it
         */
        if (file.exists()){
            file.delete();
        } 

        Connection connection = null;
        try{
            /**
             * connects to the data base and create a statemnet
             */
            String dbUrl = "jdbc:sqlite:" + filename;
		    connection = DriverManager.getConnection(dbUrl);
            Statement statement = connection.createStatement();

            /**
             * goes through every line of the text file and execute it as sql update
             */
            while(reader.hasNextLine()){
                statement.executeUpdate(reader.nextLine());
            }
            
            /**
             * closes the reader and the statement
             */
            reader.close();
            statement.close();
            System.out.println("OK.");
        }
        catch(SQLException e){
            /**
             * indicated if an SQLexception occurs
             */
            System.out.println(e.getMessage());
		} 
        finally {
            /**
             * close the connection if it is different form null
             */
			if (connection != null){
                connection.close();
            }
		}
    }
}
