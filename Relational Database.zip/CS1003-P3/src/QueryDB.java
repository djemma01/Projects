/**
 * @author 200015143
 * @since   March
 * This program allows the user to make queries on the database 
*/
import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class QueryDB{
    /**
     * This conditions reperesents the relations between the movie and the actors,
     * movie and directors, movie and genres
     */
    public static final String conditionActsIn = "Actor.actorID=ActsIn.actorID AND Movie.movieID=ActsIn.movieID";
    public static final String conditionMovieDirector = "MovieDirector.movieID=Movie.movieID AND MovieDirector.directorID = Director.directorID";
    public static final String conditionMovieGenre = "Genre.genreID=MovieGenre.genreID AND MovieGenre.movieID=Movie.movieID";
    public static void main(String[] args) {
        /**
         * file used to connect to the database
         */
        String filename = "Movies.db";
        String dbUrl = "jdbc:sqlite:" + filename;
        
        /**
         * Listing the options fro queries
         */
        System.out.println("Choose an option for your query:");
        System.out.println("\nOptions:");
        System.out.println("1.List the names of all the movies in the database.");
        System.out.println("2.List the names of the actors who perform in 'The Butterfly Effect'.");
        System.out.println("3.List the synopses of a movie with Jim Carrey in it and directed by Robert Zemeckis.");
        System.out.println("4.List the directors of the movies that have Ashton Kutcher in them.");
        System.out.println("5.List the title and the genre of all movies that have Jim Carrey in them.");
        System.out.println("6.List the title, the director and the genre of the movie that are made after 2000-01-01.\n");

        /**
         * allow the user to choose a query
         */
        Scanner reader = new Scanner(System.in);
        int option;
        try{
            option = reader.nextInt();
        }
        catch(InputMismatchException e){
               /**
         * cathc an exception if another non-integer value is inputed
         */
            System.out.println("You need to input just a single digit between 1 and 6!");
            reader.close();
            return;
        }
        reader.close();
        Connection connection = null;
        try {
            /**
             * connects to the database
             */
            connection = DriverManager.getConnection(dbUrl);

            /**
             * ask a different method dependent on the option user choose
             */
            switch (option) {
                case 1:
                    listNameofMovies(connection);
                    break;
                case 2:
                    listNameofActorsInMovie(connection);
                    break;
                case 3:
                    listPlotOfMovie(connection);
                    break;
                case 4:
                    listDirectorOfMovie(connection);
                    break;
                case 5:
                    listGenreOfMovie(connection);
                    break;
                case 6:
                    listNewMovies(connection);
                    break;        
                default:
                    /**
                     * The out put if the users put invalid option
                     */
                    System.out.println("You have put an invalid option!");
                    return;
            }
        
        }
        /**
         * catch an sql exceptions if occurs
         */
        catch(SQLException e){
            System.out.println("Invalid query!");

        }
    }
  
    /**
     * A method that creates a query that lists all names of the movies
     */
    public static void listNameofMovies(Connection connection) throws SQLException{
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("SELECT title FROM Movie");
        
        System.out.println("-------\t-------");
		while (rs.next()) {

			String title = rs.getString(1);
				
			System.out.println("Title of movies: " + title);
		}
        statement.close();
    }

    /**
     * a method that creates a query that lists the names of all actors that act in "The Butterfly effect"
     */
    public static void listNameofActorsInMovie(Connection connection) throws SQLException{
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("SELECT Actor.name FROM 'Actor','Movie','ActsIn' where " +
        conditionActsIn + " AND Movie.title = 'The Butterfly Effect'");

        System.out.println("-------\t-------");
		while (rs.next()) {

			String name = rs.getString(1);
				
			System.out.println("Name of Actor: " + name);
		}
        statement.close();

    }

    /**
     * A method that lists the plot of each movie with Jim Carrey and it and directed by Robert Zemeckis
     * @param connection used to connect to the database
     * @throws SQLException throws an exception that is catch in the main
     */
    public static void listPlotOfMovie(Connection connection) throws SQLException{
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("SELECT Movie.plot FROM 'Movie','Actor','ActsIn','MovieDirector','Director' where " +
        conditionActsIn + " AND " + conditionMovieDirector + " AND Actor.name = 'Jim Carrey' AND Director.name='Robert Zemeckis'" );

        System.out.println("-------\t-------");
		while (rs.next()) {

			String plot = rs.getString(1);
				
			System.out.println("Plot of movie: " + plot);
		}
        statement.close();
    }

    /**
     * A method that lists the directors of each movie with Ashton Kutcher
     * @param connection used to connect to the database
     * @throws SQLException throws an exception that is catch in the main
     */
    public static void listDirectorOfMovie(Connection connection) throws SQLException{
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("SELECT Director.name FROM 'Actor','Movie','ActsIn','MovieDirector','Director' where "+
        conditionActsIn + " AND Actor.name = 'Ashton Kutcher' AND " + conditionMovieDirector);

        System.out.println("-------\t-------");
		while (rs.next()) {

			String name = rs.getString(1);
				
			System.out.println("Name of Director:" + name);
		}
        statement.close();

    }
    
    /**
     * A method that lists the genre of each movie with Jim Carrey
     * @param connection used to connect to the database
     * @throws SQLException throws an exception that is catch in the main
     */
    public static void listGenreOfMovie(Connection connection) throws SQLException{
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("SELECT Movie.title,Genre.genreName FROM 'Actor','Movie','ActsIn','Genre','MovieGenre' where "+
        conditionActsIn + " AND Actor.name = 'Jim Carrey' AND " + conditionMovieGenre);

        System.out.println("-------\t-------");
		while (rs.next()) {

			String title = rs.getString(1);
            String genre = rs.getString(2);
				
			System.out.println("Movie title:" + title);
            System.out.println("Genre:" + genre);
		}
        statement.close();
        
    }

    /**
     * A method that lists the name, the director and the genre of each movie made after 2001-01-01
     * @param connection used to connect to the database
     * @throws SQLException throws an exception that is catch in the main
     */
    public static void listNewMovies(Connection connection) throws SQLException{
        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("SELECT Movie.title,Director.name,Genre.genreName FROM "
        + "'Movie','Director','Genre','MovieDirector','MovieGenre' where "+
        conditionMovieGenre + " AND Movie.ReleaseDate > '2000-01-01' AND " + conditionMovieDirector);

        System.out.println("-------\t-------");
		while (rs.next()) {

			String title = rs.getString(1);
            String director = rs.getString(2);
            String genre = rs.getString(3);
				
			System.out.println("Movie title:" + title);
            System.out.println("Director:" + director);
            System.out.println("Genre:" + genre);
		}
        statement.close();
    }

    

    
}
