/**
 * @author  200015143
 * @since   March
 * A program that populates the database with movie data
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.*;
import java.util.Scanner;

public class PopulateDB {
    public static void main(String[] args) throws SQLException{
        /**
         * files needed to populate the database
         * One file for each table
         */
        File fileMovie = new File("../addMovie.txt");
        File fileActor = new File("../addActor.txt");
        File fileDirector = new File("../addDirector.txt");
        File fileGenre = new File("../addGenre.txt");
        File fileMovieAward = new File("../addMovieAward.txt");
        File fileActorAward = new File("../addActorAward.txt");
        File fileRating = new File("../addRating.txt");
        File fileActsIn = new File("../addActsIn.txt");
        File fileMovieDirector = new File("../addMovieDirector.txt");
        File fileMovieGenre = new File("../addMovieGenre.txt");


        String filename = "Movies.db";
        Connection connection = null;
        try{
            /**
             * connects to the database
             */
            String dbUrl = "jdbc:sqlite:" + filename;
		    connection = DriverManager.getConnection(dbUrl);
            /**
             * calls all the method that populate the database
             */
            addMovie(connection,fileMovie);
            addActor(connection,fileActor);
            addDirector(connection, fileDirector);
            addGenre(connection, fileGenre);
            addMovieAward(connection, fileMovieAward);
            addActorAward(connection, fileActorAward);
            addRating(connection, fileRating);
            addActsIn(connection, fileActsIn);
            addMovieDirector(connection, fileMovieDirector);
            addMovieGenre(connection, fileMovieGenre);
            System.out.println("Data populated!");
           
        }
        catch(SQLException e){
            /**
             * catches an SQLException if it occurs
             */
            System.out.println(e.getMessage());
		}
        finally {
            /**
             * close the connection if not null
             */
			if (connection != null){
                connection.close();
            }
		}
    }

    /**
     * A method that populate the Movie table
     * @param connection use to conncet to the database
     * @param file use the data from it to populate the table
     * @throws SQLException throws an SQLException which can be caught in the main
     */
    public static void addMovie(Connection connection, File file) throws SQLException{
        Scanner reader;
        String line;
        String[] data = new String[4]; //to store all the attributes of the table
        try {
            reader = new Scanner(file); // to iterate through the file
        } catch (FileNotFoundException e) {
            /**
             * prints an appropriate message if the file is not found
             */
            System.out.println("File is not found!");
            return;
        }

        PreparedStatement statement = null;
        reader.nextLine();
        while(reader.hasNextLine()){
            line = reader.nextLine();
            data = line.split("\t");

            /**
             * prepared statement for that inserts data in the dable
             */
            statement = connection.prepareStatement("INSERT INTO Movie(plot,title,releaseDate,runningTime) VALUES (?, ?, ?, ?)");
            
            /**
             * 
             */
		    statement.setString(1,data[0]);
		    statement.setString(2,data[1]);
            //statement.setDate(3, Date.valueOf(data[2])); it is also possile to put is as date type
            statement.setString(3, data[2]);
            statement.setInt(4,Integer.parseInt(data[3]));

		    statement.executeUpdate(); //executes statement
        }

        reader.close();
        if (statement != null){
		    statement.close();  
        }
    }

    /**
     * A method that populate the Actor table
     * @param connection use to conncet to the database
     * @param file use the data from it to populate the table
     * @throws SQLException throws an SQLException which can be caught in the main
     */
    public static void addActor(Connection connection, File file) throws SQLException{
        Scanner reader;
        String line;
        String[] data = new String[2];
        try {
            reader = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("File is not found!");
            return;
        }

        PreparedStatement statement = null;
        reader.nextLine();
        while(reader.hasNextLine()){
            line = reader.nextLine();
            data = line.split("\t");
            statement = connection.prepareStatement("INSERT INTO Actor(name,DoB) VALUES (?, ?)");
            
		    statement.setString(1,data[0]);
            //statement.setDate(2, java.sql.Date.valueOf(data[1]));
            statement.setString(2,data[1]);
		    statement.executeUpdate();
        }

        reader.close();
        if (statement != null){
		    statement.close();  
        }
    }

    /**
     * A method that populate the Genre table
     * @param connection use to conncet to the database
     * @param file use the data from it to populate the table
     * @throws SQLException throws an SQLException which can be caught in the main
     */
    public static void addGenre(Connection connection, File file) throws SQLException{
        Scanner reader;
        String line;

        try {
            reader = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("File is not found!");
            return;
        }

        PreparedStatement statement = null;
        reader.nextLine();
        while(reader.hasNextLine()){
            line = reader.nextLine();
            statement = connection.prepareStatement("INSERT INTO Genre(genreName) VALUES (?)");
            
		    statement.setString(1,line);
            statement.executeUpdate();
        }

        reader.close();
        if (statement != null){
		    statement.close();  
        }
    }

    /**
     * A method that populate the Director table
     * @param connection use to conncet to the database
     * @param file use the data from it to populate the table
     * @throws SQLException throws an SQLException which can be caught in the main
     */
    public static void addDirector(Connection connection, File file) throws SQLException{
        Scanner reader;
        String line;

        try {
            reader = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("File is not found!");
            return;
        }

        PreparedStatement statement = null;
        reader.nextLine();
        while(reader.hasNextLine()){
            line = reader.nextLine();
            statement = connection.prepareStatement("INSERT INTO Director(name) VALUES (?)");
            
		    statement.setString(1,line);
            statement.executeUpdate();
        }

        reader.close();
        if (statement != null){
		    statement.close();  
        }
    }
    
    /**
     * A method that populate the ActorAward table
     * @param connection use to conncet to the database
     * @param file use the data from it to populate the table
     * @throws SQLException throws an SQLException which can be caught in the main
     */
    public static void addActorAward(Connection connection, File file) throws SQLException{
        Scanner reader;
        String line;
        String[] data = new String[2];
        try {
            reader = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("File is not found!");
            return;
        }

        PreparedStatement statement = null;
        reader.nextLine();
        while(reader.hasNextLine()){
            line = reader.nextLine();
            data = line.split("\t");
            statement = connection.prepareStatement("INSERT INTO ActorAwards(awardName,actorID) VALUES (?, ?)");
            
		    statement.setString(1,data[0]);
            statement.setInt(2, Integer.parseInt(data[1]));
		    statement.executeUpdate();
        }

        reader.close();
        if (statement != null){
		    statement.close();  
        }
    }

    /**
     * A method that populate the MovieAward table
     * @param connection use to conncet to the database
     * @param file use the data from it to populate the table
     * @throws SQLException throws an SQLException which can be caught in the main
     */
    public static void addMovieAward(Connection connection, File file) throws SQLException{
        Scanner reader;
        String line;
        String[] data = new String[2];
        try {
            reader = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("File is not found!");
            return;
        }

        PreparedStatement statement = null;
        reader.nextLine();
        while(reader.hasNextLine()){
            line = reader.nextLine();
            data = line.split("\t");
            statement = connection.prepareStatement("INSERT INTO MovieAwards(awardName,movieID) VALUES (?, ?)");
            
		    statement.setString(1,data[0]);
            statement.setInt(2, Integer.parseInt(data[1]));
		    statement.executeUpdate();
        }

        reader.close();
        if (statement != null){
		    statement.close();  
        }
    }

    /**
     * A method that populate the Rating table
     * @param connection use to conncet to the database
     * @param file use the data from it to populate the table
     * @throws SQLException throws an SQLException which can be caught in the main
     */
    public static void addRating(Connection connection, File file) throws SQLException{
        Scanner reader;
        String line;
        String[] data = new String[3];
        try {
            reader = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("File is not found!");
            return;
        }

        PreparedStatement statement = null;
        reader.nextLine();
        while(reader.hasNextLine()){
            line = reader.nextLine();
            data = line.split("\t");
            statement = connection.prepareStatement("INSERT INTO Rating(source,value,movieID) VALUES (?, ?, ?)");
		    statement.setString(1,data[0]);
            statement.setDouble(2, Double.parseDouble(data[1]));
            statement.setInt(3, Integer.parseInt(data[2]));
		    statement.executeUpdate();
        }

        reader.close();
        if (statement != null){
		    statement.close();  
        }
    }

    /**
     * A method that populate the ActsIn table
     * @param connection use to conncet to the database
     * @param file use the data from it to populate the table
     * @throws SQLException throws an SQLException which can be caught in the main
     */
    public static void addActsIn(Connection connection, File file) throws SQLException{
        Scanner reader;
        String line;
        String[] data = new String[2];
        try {
            reader = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("File is not found!");
            return;
        }

        PreparedStatement statement = null;
        reader.nextLine();
        while(reader.hasNextLine()){
            line = reader.nextLine();
            data = line.split("\t");
            statement = connection.prepareStatement("INSERT INTO ActsIn(movieID,actorID) VALUES (?, ?)");
            
            statement.setInt(1, Integer.parseInt(data[0]));
            statement.setInt(2, Integer.parseInt(data[1]));

		    statement.executeUpdate();
        }

        reader.close();
        if (statement != null){
		    statement.close();  
        }
    }

    /**
     * A method that populate the MovieGenre table
     * @param connection use to conncet to the database
     * @param file use the data from it to populate the table
     * @throws SQLException throws an SQLException which can be caught in the main
     */
    public static void addMovieGenre(Connection connection, File file) throws SQLException{
        Scanner reader;
        String line;
        String[] data = new String[2];
        try {
            reader = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("File is not found!");
            return;
        }

        PreparedStatement statement = null;
        reader.nextLine();
        while(reader.hasNextLine()){
            line = reader.nextLine();
            data = line.split("\t");
            statement = connection.prepareStatement("INSERT INTO MovieGenre(genreID,movieID) VALUES (?, ?)");
            
            statement.setInt(1, Integer.parseInt(data[0]));
            statement.setInt(2, Integer.parseInt(data[1]));

		    statement.executeUpdate();
        }

        reader.close();
        if (statement != null){
		    statement.close();  
        }
    }

    /**
     * A method that populate the MovieDirector table
     * @param connection use to conncet to the database
     * @param file use the data from it to populate the table
     * @throws SQLException throws an SQLException which can be caught in the main
     */
    public static void addMovieDirector(Connection connection, File file) throws SQLException{
        Scanner reader;
        String line;
        String[] data = new String[2];
        try {
            reader = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("File is not found!");
            return;
        }

        PreparedStatement statement = null;
        reader.nextLine();
        while(reader.hasNextLine()){
            line = reader.nextLine();
            data = line.split("\t");
            statement = connection.prepareStatement("INSERT INTO MovieDirector(directorID,movieID) VALUES (?, ?)");
            
            statement.setInt(1, Integer.parseInt(data[0]));
            statement.setInt(2, Integer.parseInt(data[1]));

		    statement.executeUpdate();
        }

        reader.close();
        if (statement != null){
		    statement.close();  
        }
    }  
}
