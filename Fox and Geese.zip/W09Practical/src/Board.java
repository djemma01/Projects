public class Board {

    // The following five constants were defined in the starter code (kt54)
    private static final int  BOARD_SIZE = 7;
    private static final char FREE    = '.';
    private static final char INVALID = ' ';
    private static final char FOX     = '*';
    private static final char GOOSE   = 'o';

    private int boardsize;
    private char[][] board;
    private int[] foxCor = {boardsize/2,boardsize/2+25};
    
   


    // Default constructor was provided by the starter code. Extend as needed (kt54) 
    public Board() {
        this.boardsize = BOARD_SIZE;

        board = new char[boardsize][boardsize];

        // Clear all playable fields
        for(int x=0; x<boardsize; x++)
            for(int y=0; y<boardsize; y++)
                board[x][y] = FREE;

        // Put a single fox in the middle
        board[boardsize/2][boardsize/2+2] = FOX;

        board[0][0] = INVALID;
        board[0][1] = INVALID;
        board[1][0] = INVALID;
        board[1][1] = INVALID;
        board[0][boardsize-2] = INVALID;
        board[0][boardsize-1] = INVALID;
        board[1][boardsize-2] = INVALID;
        board[1][boardsize-1] = INVALID;
        board[boardsize-1][0] = INVALID;
        board[boardsize-1][1] = INVALID;
        board[boardsize-2][0] = INVALID;
        board[boardsize-2][1] = INVALID;
        board[boardsize-1][boardsize-2] = INVALID;
        board[boardsize-1][boardsize-1] = INVALID;
        board[boardsize-2][boardsize-2] = INVALID;
        board[boardsize-2][boardsize-1] = INVALID;

        for(int x=0; x<boardsize; x++){
            for(int y=0; y<boardsize/2+1; y++){
                if (board[x][y] != INVALID)
                board[x][y] = GOOSE;
            }
        }

        board[2][3] = FREE;
        board[3][3] = FREE;
        board[4][3] = FREE;


    }

    public int[] getFoxCor(){
        for(int y=0; y<boardsize; y++)
        {
            for(int x=0; x<boardsize; x++) {
                if(board[x][y] == FOX){
                    foxCor[0] = x;
                    foxCor[1] = y;
                    break;
                }

            }
        }
        return foxCor;

    }
    public int getBoardsize() {
        return boardsize;
    }

    public static char getFox() {
        return FOX;
    }
    public static char getGoose() {
        return GOOSE;
    }
    public static char getFree() {
        return FREE;
    }
    public static char getInvalid() {
        return INVALID;
    }
    public char[][] getBoard() {
        return board;
    }

    // Prints the board. This method was provided with the starter code. Better not modify to ensure
    // output consistent with the autochecker (kt54)
    public void printBoard() {

        for(int y=0; y<boardsize; y++)
        {
            for(int x=0; x<boardsize; x++) {
                System.out.print(" ");
                switch(board[x][y]) {
                    case FREE: 
                        System.out.print(".");
                        break;
                    case FOX:
                        System.out.print("*");
                        break;
                    case GOOSE:
                        System.out.print("o");
                        break;
                    default:
                        System.out.print(" ");
                }
            }
            System.out.println();
        }
    }

}
