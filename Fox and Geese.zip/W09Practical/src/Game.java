import java.util.Scanner;

public class Game {
    // The following five constants were defined in the starter code (kt54)
    private static String FOXPLAYS_MSG      = "Fox plays. Enter move:";
    private static String GEESEPLAY_MSG     = "Geese play. Enter move:";
    private static String ILLEGALMOVE_MSG   = "Illegal move!";
    private static String FOXWINS_MSG       = "Fox wins!";
    private static String GEESEWIN_MSG      = "Geese win!";

    //varibles used in the program
    private boolean geeseTurn = true ;
    private static int geeseNumber = 17;
    private boolean done = false;
    private int size;
    
    
    //declaring the board
    private Board gameBoard;
    

    // Minimal constructor. Expand as needed (kt54)
    public Game() {
        gameBoard = new Board();
        size = gameBoard.getBoardsize();
    }

    // Build on this method to implement game logic.
    public void play() {

        Scanner reader = new Scanner(System.in);

    
        

        while(!done) {
            
            int row_i;
            int column_i;
            int row_f;
            int column_f;
            do{
                
            gameBoard.printBoard();
        
            //check which message to print
            if(geeseTurn)
                System.out.println(GEESEPLAY_MSG);
            else
                System.out.println(FOXPLAYS_MSG);


            // Read the lines as a string 
            String command1 = reader.nextLine().trim();
            if(command1.equalsIgnoreCase("quit")){
                return;
            }
            String command2 = reader.nextLine().trim();
            String command3 = reader.nextLine().trim();
            String command4 = reader.nextLine().trim();

            
            // convert the command into an integer that can be used as an index
            row_i = Integer.parseInt(command1);
            column_i = Integer.parseInt(command2);
            row_f = Integer.parseInt(command3);
            column_f = Integer.parseInt(command4);
            } 
            while(!makeValidMove(row_i, column_i, row_f, column_f));
        
            //Check if someone wins
            if(checkGeeseWin()){
                gameBoard.printBoard();
                System.out.println(GEESEWIN_MSG);
                done = true;
                return;
            }
            if(checkFoxWin()){
                gameBoard.printBoard();
                System.out.println(FOXWINS_MSG);
                done = true;
            }     
        }      
    }

    //a method that make the move
    private void makeMove(int row_i,int column_i,int row_f,int column_f){
        if(captureGoose(row_i, column_i, row_f, column_f)){
            gameBoard.getBoard()[(row_i+row_f)/2][(column_i+column_f)/2] = Board.getFree();
            geeseNumber--;
        }
        gameBoard.getBoard()[row_f][column_f] = gameBoard.getBoard()[row_i][column_i];
        gameBoard.getBoard()[row_i][column_i] = Board.getFree();


    }

    //check if the move is valid and controls the turns
    private boolean makeValidMove(int row_i,int column_i,int row_f,int column_f){
        if((row_i >= size || row_f >= size || row_i < 0 || row_f <0)||
        (column_i >= size || column_f >= size || column_i < 0 || column_f < 0)){
            System.out.println(ILLEGALMOVE_MSG);
            return false;
        }
        if(geeseTurn){
            if(gameBoard.getBoard()[row_i][column_i] != Board.getGoose() ||
                gameBoard.getBoard()[row_f][column_f] == Board.getInvalid() ||
                gameBoard.getBoard()[row_f][column_f] != Board.getFree() ||
                (row_i >= size || row_f >= size || row_i < 0 || row_f <0)||
                (column_i >= size || column_f >= size || column_i < 0 || column_f < 0)||
                !areAdjacent(row_i, column_i,row_f,column_f))
                {
                System.out.println(ILLEGALMOVE_MSG);
                return false;
            }
            else{
            makeMove(row_i, column_i, row_f, column_f);
            geeseTurn = false;
            return true;
            }
        }
        
        else{
            if(gameBoard.getBoard()[row_i][column_i] != Board.getFox() ||
                gameBoard.getBoard()[row_f][column_f] == Board.getInvalid() ||
                gameBoard.getBoard()[row_f][column_f] != Board.getFree()||
                (!captureGoose(row_i,column_i,row_f,column_f) &&
                !areAdjacent(row_i, column_i,row_f,column_f))){
                System.out.println(ILLEGALMOVE_MSG);
                return false;
                }
            else{
                makeMove(row_i, column_i, row_f, column_f);
                geeseTurn = true;
                return true;
            }
        }
    }

    //check if two pairs of coordinates belongs to adjacent squares
    //https://www.tutorialspoint.com/java/lang/math_abs_int.htm - Math.abs usage
    private boolean areAdjacent(int row_i,int column_i,int row_f,int column_f){
        if((Math.abs(row_i - row_f) <= 1 && Math.abs(column_i - column_f) <= 1) &&
                    (row_i != row_f || column_i !=column_f)){
            return true;
        }
        return false;
    }
    
    //method that captures a goose and uses two pairs of coordinates
    private boolean captureGoose(int row_i,int column_i,int row_f,int column_f){
        for(int i = -1; i <= 1; i++){
            for(int j = -1; j <= 1;j++){
                if((row_i+i > -1 && column_i+j > -1 && row_i+i < size && column_i+j < size) &&
                gameBoard.getBoard()[row_i+i][column_i+j] == Board.getGoose()){
                    if(row_i + i * 2 == row_f && column_i + j * 2 == column_f){
                        return true;
                    }

                }
            }
        }
        return false;
    }
     
    //method to check if geese win
    private boolean checkGeeseWin(){
        int fox_x = gameBoard.getFoxCor()[0];
        int fox_y = gameBoard.getFoxCor()[1];
        for(int i = -1; i <= 1; i++){
            for(int j = -1; j <= 1;j++){
                if((fox_x+i > -1 && fox_y+j > -1 && fox_x+i < size && fox_y+j < size) &&
                gameBoard.getBoard()[fox_x+i][fox_y+j] == Board.getGoose()){
                    if((fox_x+i*2 > -1 && fox_y+j*2 > -1 && fox_x+i*2 < size && fox_y+j*2 < size) &&
                    gameBoard.getBoard()[fox_x+i*2][fox_y+j*2] == Board.getFree()){
                        return false;
                    }
                }
                if((fox_x+i > -1 && fox_y+j >-1 && fox_x+i < size && fox_y+j < size) &&
                    gameBoard.getBoard()[fox_x+i][fox_y+j] == Board.getFree()){
                    return false;
                }
            }
        }
        
    return true;
    }

    //a method to check if the fox wins
    private boolean checkFoxWin(){
        if(geeseNumber == 0)
            return true;
        return false;

    }
    
}
