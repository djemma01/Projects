public class W09practicalEx {
    
    public static void main(String[] args) {



        //make an object of class GameEx
        GameEx game = new GameEx();

        //play the game
        game.play();
    }
    
}
