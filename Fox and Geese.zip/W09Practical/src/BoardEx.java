public class BoardEx {
    // The following five constants are the possible are
    // the possible states in the game and size of the board
    private static final int  BOARD_SIZE = 7;
    private static final char FREE    = '.';
    private static final char INVALID = ' ';
    private static final char FOX     = '*';
    private static final char GOOSE   = 'o';

    //declaring variables used in the program
    private int foxNumber;
    private int maxFoxNumber;
    private int boardsize;
    private char[][] board;
    private double boardRatio;
    private int geeseNumber;
    int sizeControl;
    private int[] foxCor = new int[2];
    
    
   


    // Default constructor was provided by the starter code.(kt54)
    // Creating the appearence of the board 
    public BoardEx(int boardsize) {
        this.boardsize = boardsize;

        board = new char[boardsize][boardsize];

        // Clear all playable fields
        for(int x=0; x<boardsize; x++)
            for(int y=0; y<boardsize; y++)
                board[x][y] = FREE;

        boardRatio =(boardsize / (double)BOARD_SIZE);
        sizeControl = (int) Math.round(boardRatio*2);

        //making the shape of the board
        for(int i = 0; i < boardsize; i++){
            for(int j = 0; j < boardsize; j++){
                if(i < sizeControl && j < sizeControl){
                    board[i][j] = INVALID;
                    }
                if(i < sizeControl && j > (boardsize - sizeControl - 1)){
                    board[i][j] = INVALID;
                }
                if(i > boardsize - sizeControl - 1 && j < sizeControl){
                    board[i][j] = INVALID;
                }
                if(i > boardsize - sizeControl - 1 && j > boardsize - sizeControl - 1){
                    board[i][j] = INVALID;
                }

            }
        }

        //adding geese to the board
        for(int x=0; x<boardsize; x++){
            for(int y=0; y<boardsize/2+1; y++){
                if (board[x][y] != INVALID){
                    board[x][y] = GOOSE;
                    if(y > boardsize / 2 - sizeControl / 2 && y <= boardsize / 2 && x >= sizeControl && x < boardsize - sizeControl)
                    board[x][y] = FREE;
                }
            }
        }

        //conting the geese
        setGeeseNumber();

        //finding the maximum number of foxes depending on the board
        maxFoxNumber = boardsize - 2 * sizeControl;
    }

    //a method that finding the coordinates of the fox
    public int[] getFoxCor(){
        for(int y=0; y<boardsize; y++)
        {
            for(int x=0; x<boardsize; x++) {
                if(board[x][y] == FOX){
                    foxCor[0] = x;
                    foxCor[1] = y;
                    break;
                }

            }
        }
        return foxCor;

    }

    //a method that counts the geese
    private void setGeeseNumber() {
        for(int x=0; x<boardsize; x++){
            for(int y=0; y<boardsize; y++){
                if(board[x][y] == GOOSE){
                    geeseNumber++;
                }
            }
        }
        
    }

    /*a method that places the foxes
    it does it in a line right next to each other staritng from the center
     */
    public void setFoxes(int foxNumber){
        for(int j=0; j < foxNumber;j++){
            if(j % 2 == 0)
            board[boardsize / 2 + j/2][boardsize - sizeControl] = FOX;
            if(j % 2 == 1)
            board[boardsize / 2 - (j+1)/2][boardsize - sizeControl] = FOX;
        }
            
    }

    //getter for the number of geese
    public int getGeeseNumber() {
        return geeseNumber;
    }

    //a method that decreases the number of geese whe a goose is captured
    public int decreaseGeeseNumber() {
        return --geeseNumber;
    }

    //getter for the size of the board
    public int getBoardsize() {
        return boardsize;
    }

    //setter for the number of foxes take form the user
    public void setFoxNumber(int foxNumber) {
        this.foxNumber = foxNumber;
    }

    //getter for the number of foxes
    public int getFoxNumber() {
        return foxNumber;
    }

    //getter for the max number of foxes
    public int getMaxFoxNumber() {
        return maxFoxNumber;
    }

    //methods that take the possible state of a square
    public static char getFox() {
        return FOX;
    }
    public static char getGoose() {
        return GOOSE;
    }
    public static char getFree() {
        return FREE;
    }
    public static char getInvalid() {
        return INVALID;
    }

    //getter for the board
    public char[][] getBoard() {
        return board;
    }


    // Prints the board. This method was provided with the starter code. Better not modify to ensure
    // output consistent with the autochecker (kt54)
    public void printBoard() {

        for(int y=0; y<boardsize; y++)
        {
            for(int x=0; x<boardsize; x++) {
                System.out.print(" ");
                switch(board[x][y]) {
                    case FREE: 
                        System.out.print(".");
                        break;
                    case FOX:
                        System.out.print("*");
                        break;
                    case GOOSE:
                        System.out.print("o");
                        break;
                    default:
                        System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
    
}
