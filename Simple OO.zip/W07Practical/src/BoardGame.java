//libraries needed to take periods and dates
import java.time.LocalDate;
import java.time.Period;

public class BoardGame {
    //declaring the class attributes
    private String name;
    private int borrowingTime;
    private double replaceCost;
    private Hall hall;
    private LocalDate borrowingDate;
    private Student student1;
    private Student student2;
    private boolean availability;
    private LocalDate dueDate;
    private double fine;
    private LocalDate today = LocalDate.now();
    private int overdueDays;
    
    //create a constructor for the class fot the things that should always be initialized
    public BoardGame(String name, int borrowingTime, double replaceCost, Hall hall){
        this.name = name;
        this.setBorrowingTime(borrowingTime);
        this.setReplaceCost(replaceCost);
        this.hall = hall;
        availability = true;

    }

     //make setter and getter for the name
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }

     //make setter and getter for days a game can be borrowed
    public void setBorrowingTime(int borrowingTime){
        if(borrowingTime >= 0)
        this.borrowingTime = borrowingTime;
    }
    public int getBorrowingTime(){
        return borrowingTime;
    }

     //make setter and getter for the replace cost
    public void setReplaceCost(double replaceCost){
        if(replaceCost >= 0 )
        this.replaceCost = replaceCost;
    }
    public double getReplaceCost(){
        return replaceCost;
    }

     //make setter and getter for the hall
    public void setHall(Hall hall){
        this.hall = hall;
    }
    public Hall getHall(){
        return hall;
    }

    //make setter and getter for date it was borrowed
    public void setBorrowingDate(LocalDate borrowingDate){
        this.borrowingDate = borrowingDate;
    }
    public LocalDate getBorrowingDate(){
        return borrowingDate;
    }

    //make setter and getter for student1
    public void setStudent1(Student student1){
        this.student1 = student1;
    }
    public Student getStudent1(){
        return student1;
    }

    //make setter and getter for student2
    public void setStudent2(Student student2){
        this.student2 = student2;
    }
    public Student getStudent2(){
        return student2;
    }

    //get the availability of the game
    public boolean getAvailability(){
        return availability;
    }

    //a method that gives the game to two the two students
    public void loanGame(Student student1, Student student2, LocalDate borrowingDate){
        if(availability) {
            if(student1.getHall() == this.getHall() || student2.getHall() == this.getHall()){
                if(student1.getBorrowedGames() < 1 && student2.getBorrowedGames() < 1){
                    this.student1 = student1;
                    this.student2 = student2;
                    this.student1.getGame();
                    this.student2.getGame();
                    this.setBorrowingDate(borrowingDate);
                    this.getDueDate();
                    availability = false;
                }
                else
                    System.out.println("One of the students has already borrowed a game");
            }
            else
            System.out.println("You cannot borrow games if you are not from this hall.");
        }
        else
        System.out.println("The game has already been borrowed.");
        
    }

    //method that means the game was returned
    public void returnGame(){
        if(!availability){
            this.student1.returnGame();
            student1 = null;
            this.student2.returnGame();
            student2 = null;
            borrowingDate = null;
            dueDate = null;
            availability = true;
        }
        else 
            System.out.println("The game wasn not borrowed!");
    }

    //a method to find when a game is due to
    public LocalDate getDueDate(){
        dueDate = borrowingDate.plusDays(borrowingTime);
        return dueDate; 
    }

    //a method to find how many days a student was overdue
    public int getOverdueDays() {
        overdueDays = (Period.between(dueDate,today)).getDays();
        if(overdueDays > 0)
            return overdueDays;
        else
            return 0;
    }

    //a method to get the fine for the overdue days
    public double getFine(){
        fine = hall.getLateReturnFine()*this.getOverdueDays();
        return fine;
    }



    //print the details of the board game
    public void printDetails(){
        System.out.println("Name: " + name);
        System.out.println("Replacement cost: £" + replaceCost);
        System.out.println("The game can be borrowed for: " + borrowingTime + " days");
        System.out.println("The game belongs to: " + hall.getName());
        if(student1 == null || student2 == null){
            System.out.println("These game is not borrowed at the momment");
        }
        else
            System.out.println("The game is now borrowed by: " + student1.getName()+" and "+ student2.getName());
        if(!(dueDate == null))    
        System.out.println("The day the game is due back:" + dueDate);
    }


}

