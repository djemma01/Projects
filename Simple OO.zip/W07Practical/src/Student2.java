public class Student2 {
    //declaring the class attributes
    private long matricNumber;
    private String name;
    private Hall2 hall;
    private int borrowedGames = 0;
    private double fine = 0;
    private BoardGame2 game;
    private Account account;
    
    //create a constructor for the class
    public Student2(long matriculationNumber, String name, Hall2 hall, Account account){
        this.matricNumber = matriculationNumber;
        this.name = name;
        this.hall = hall;
        this.account = account;
    }

    //make setter and getter for matriculation number
    public void setMatricNumber(long matricNumber){
        this.matricNumber = matricNumber;
    }
    public long getMatricNumber(){
        return matricNumber;
    }

    //make setter and getter for the name
    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return name;
    }

    //make setter and getter for the hall
    public void setHall(Hall2 hall){
        this.hall = hall;
    }
    public Hall2 getHall(){
        return hall;
    }

    //increase the number of borrowed games if a student takes a game
    public int getGame(BoardGame2 game) {
        this.game = game;
        return ++borrowedGames;
    }

    //decrease the number of borrowed games if a student returns a game
    public int returnGame(){
        return --borrowedGames;
    }

    //getter fot the number of games a student has borrowed
    public int getBorrowedGames() {
        return borrowedGames;
    }

    //getter and setter for the fine and a method to add fine
    public void setFine(double fine){
        this.fine = fine;
    }

    public double getFine() {
        return fine;
    }

    public void addFine(){
        this.fine = this.fine + game.getFine();
        
    }

    //getter and setter for the account
    public void setAccount(Account account) {
        this.account = account;
    }

    public Account getAccount() {
        return account;
    }





    //printing all the atributes
    public void printDetails(){
        System.out.println("Name: " + name);
        System.out.println("Matriculation number: " + matricNumber);
        if(!(hall == null))
        System.out.println("Hall:" + hall.getName());
        else
        System.out.println("Hall: none");
        System.out.println("Borrowed games: " + borrowedGames);
        System.out.println("Fine: £" + fine);
        System.out.println("Student current balance: £" + account.getCurrentBalance());
        

    }
   


}
