public class W07Practical {
    public static void main(String[] args) throws Exception {
       //tests for part 3
        Tests tests1 = new Tests();
        Tests tests2 = new Tests();
        Tests tests3 = new Tests();

        tests1.scenario1();
        tests2.scenario2();
        tests3.scenario3();

        //tests for part 4
        Tests2 tests4 = new Tests2();
        Tests2 tests5 = new Tests2();
        tests4.scenario4();
        tests5.scenario5();
    }
}
