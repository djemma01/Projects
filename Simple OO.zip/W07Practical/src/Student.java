public class Student {
    //declaring the class attributes
    private long matricNumber;
    private String name;
    private Hall hall;
    private int borrowedGames = 0;
    
    //create a constructor for the class
    public Student(long matriculationNumber, String name, Hall hall){
        this.matricNumber = matriculationNumber;
        this.name = name;
        this.hall = hall;
    }

    //make setter and getter for matriculation number
    public void setMatricNumber(long matricNumber){
        this.matricNumber = matricNumber;
    }
    public long getMatricNumber(){
        return matricNumber;
    }

    //make setter and getter for the name
    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return name;
    }

    //make setter and getter for the hall
    public void setHall(Hall hall){
        this.hall = hall;
    }
    public Hall getHall(){
        return hall;
    }

    //increase the number of borrowed games if a student takes a game
    public int getGame() {
        return ++borrowedGames;
    }

    //decrease the number of borrowed games if a student returns a game
    public int returnGame(){
        return --borrowedGames;
    }

    //getter fot the number of games a student has borrowed
    public int getBorrowedGames() {
        return borrowedGames;
    }



    //printing all the atributes
    public void printDetails(){
        System.out.println("Name: " + name);
        System.out.println("Matriculation number: " + matricNumber);
        if(!(hall == null))
        System.out.println("Hall:" + hall.getName());
        else
        System.out.println("Hall: none");
        System.out.println("Borrowed games: " + borrowedGames);
        

    }
   


}
