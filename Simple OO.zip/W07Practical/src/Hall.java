public class Hall {
    //declaring the class attributes
    private String name;
    private String address;
    private double lateReturnFine; //per day

    //making a constructor for the class
    public Hall(String name, String address, double lateReturnFine){
        this.name = name;
        this.address = address;
        this.setLateReturnFine(lateReturnFine);
    }


    //making getter and setter for the name
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }

    //making getter and setter for the address
    public void setAddress(String address){
        this.address = address;
    }
    public String getAddress(){
        return address;
    }

    //making getter and setter for the fine if the game is returned late
    public void setLateReturnFine(double lateReturnFine){
        if(lateReturnFine >= 0 )
        this.lateReturnFine = lateReturnFine;
    }
    public double getLateReturnFine(){
        return lateReturnFine;
    }

    //printing all the attributes
    public void printDetails(){
        System.out.println("Name of the Hall of residence:" + name);
        System.out.println("Address of the Hall of residence:" + address);
        System.out.println("Fine for late return of the game" + lateReturnFine);
    }

}
