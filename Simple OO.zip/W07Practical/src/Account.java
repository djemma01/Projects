import java.time.LocalDate;

public class Account {
    //declaring the attributes of the class
    private String accountNumber;
    private LocalDate dateCreated;
    private double currentBalance;

    //creating a constructor forn the class
    public Account(String accountNumber, LocalDate dateCreated, double currentBalance){
        this.accountNumber = accountNumber;
        this.dateCreated = dateCreated;
        this.currentBalance = currentBalance;
       
    }

    //getter and setter for the the account number
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    //getter and setter for the created date
    public void setDateCreated(LocalDate dateCreated) {
        this.dateCreated = dateCreated;
    }

    public LocalDate getDateCreated() {
        return dateCreated;
    }

    //getter and setter for the current balance
    public void setCurrentBalance(double currentBalance) {
        this.currentBalance = currentBalance;
    }

    public double getCurrentBalance() {
        return currentBalance;
    }

    //methods to change the current balance
    public void addBalance(double profit) {
        currentBalance = currentBalance + profit;
        
    }

    public void deductBalance(double fine) {
        currentBalance = currentBalance - fine;
        
    }
    
}
