import java.time.LocalDate;

public class Tests2 {
    //creating and initializing objects using a constructor
    private LocalDate dateAccount = LocalDate.of(2018,5,23);
    private Account account1 = new Account("NWBK60161331926819", dateAccount,50);
    private Account account2 = new Account("NWBK6556137892566", dateAccount,100);
    private Account account3 = new Account("NWBK3657650946543", dateAccount,75);
    private Account account4 = new Account("NWBK8693463566764", dateAccount,0);
    private Hall2 hall1 = new Hall2("Whitehorn Hall", "Kennedy Garden", 3.0, 15.0);
    private Hall2 hall2 = new Hall2("John Burnet Hall", "Links Crescent", 2.0, 10.0);
    private Student2 student1 = new Student2(200016152,"John Bennet", null, account1);
    private Student2 student2 = new Student2(200016152,"Jeremy Couzuns", hall2, account2);
    private Student2 student3 = new Student2(200013147,"Maria Adams", hall1, account3);
    private Student2 student4 = new Student2(200014347,"Petar Langov", hall1, account4);
    private BoardGame2 boardGame1 = new BoardGame2("Catan", 8, 30.0, hall1);
    private BoardGame2 boardGame2 = new BoardGame2("Exploding Kittens", 3, 9, hall2);

    //declaring and initializing the dates
    private LocalDate date1 = LocalDate.of(2020,10,27);
    private LocalDate date2 = LocalDate.of(2020,10,10);
    private LocalDate date3 = LocalDate.of(2020,10,26);
    private LocalDate date4 = LocalDate.of(2020,10,15);
    



    // The scenario tests what happens if a student who does not
    //have enough money to replace the cost of the game

    public void scenario4() {
     
        System.out.println("\n\nSCENARIO 4:");

        System.out.println("If person who does not have enough money in his account tries to borrow a game:");
        boardGame2.loanGame(student2, student4, date4);
        System.out.println("And the game was not taken:");
        boardGame2.returnGame(date3);

        boardGame1.loanGame(student1, student3, date4);
        boardGame1.returnGame(date3);
        

        student1.printDetails();
        student2.printDetails();
        student3.printDetails();
        student4.printDetails();
    }

    // this scenario tests what happens if the fine of the student 
    // is more than the limit of the hall
    public void scenario5() {
        System.out.println("\n\nSCENARIO 5:");
        
        boardGame2.loanGame(student2, student3, date2);
        boardGame2.returnGame(date3);
        System.out.println("When one of the students is over the hall limit:");
        boardGame1.loanGame(student3, student1, date1);

        student1.printDetails();
        student2.printDetails();
        student3.printDetails();
        student4.printDetails();

    }

}
