import java.time.LocalDate;

public class Tests {
    //creating and initializing objects using a constructor
    private Hall hall1 = new Hall("Whitehorn Hall", "Kennedy Garden", 3.0);
    private Hall hall2 = new Hall("John Burnet Hall", "Links Crescent", 2.0);
    private Student student1 = new Student(200016152,"John Bennet", null);
    private Student student2 = new Student(200016152,"Jeremy Couzuns", hall2);
    private Student student3 = new Student(200013147,"Maria Adams", hall1);
    private Student student4 = new Student(200014347,"Petar Langov", hall1);
    private BoardGame boardGame1 = new BoardGame("Catan", 8, 30.0, hall1);
    private BoardGame boardGame2 = new BoardGame("Exploding Kittens", 3, 15, hall2);

    //declaring and initializing the dates
    private LocalDate date1 = LocalDate.of(2020,10,27);
    private LocalDate date2 = LocalDate.of(2020,10,28);
    private LocalDate date3 = LocalDate.of(2020,10,26);
    private LocalDate date4 = LocalDate.of(2020,10,15);



    // The scenario tests what is happening if students out of the hall try 
    // to borrow a game and shows what is happening when a game is taken and retunred

    public void scenario1() {
        System.out.println("SCENARIO 1:");
        System.out.println("If students out of this hall try to borrow the game:");
        boardGame1.loanGame(student1, student2, date1);
        System.out.println("Game:");
        boardGame1.printDetails();

        System.out.println("\nWhen the students can borrow this game:");
        boardGame1.loanGame(student2, student3, date1);
        boardGame1.printDetails();

        System.out.println("\nWhen the game is returned:");
        boardGame1.returnGame();
        boardGame1.printDetails();

        
    }

    // this scenario tests what happens if on of the students have already 
    // borrowed a game or if the game was borrowed before them
    public void scenario2() {
        System.out.println("\n\nSCENARIO 2:");
        boardGame1.loanGame(student2, student3, date2);

        System.out.println("If a student tries to borrow second game:");
        boardGame2.loanGame(student2, student4, date1);
        System.out.println("\nIf someone has already borrowed the game:");
        boardGame1.loanGame(student1, student4, date3);
        
        System.out.println("\nGame 1:");
        boardGame1.printDetails();
        System.out.println("\nStudent 2:");
        student2.printDetails();

        
    }

    // the scenario test what happens when a student is overdue
    public void scenario3() {
        System.out.println("\n\nSCENARIO 3:");
        boardGame1.loanGame(student2, student3, date4);
        System.out.println("The game is overdue with: " + boardGame1.getOverdueDays() + " days" );
        System.out.println("The fine is: £" + boardGame1.getFine());
        

        
    }
}
