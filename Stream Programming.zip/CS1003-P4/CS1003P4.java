/**
 * @author 200015143
 * @since April 2021
 * A program that conducts a similarity search of a certain phrase
 * in several text files
 */
/**
 * Libraries needed for Spark
 */
import org.apache.spark.*;
import org.apache.spark.api.java.*;
import scala.Tuple2;

import java.util.*;




class CS1003P4 {
    public static void main(String[] args) {

        /**
         * Check whether there are 3 arguments
         * if not prints an appropriate message
         */
        if(args.length!=3){
            System.out.println("You are putting " + args.length + " command line arguments,but the program requires just 3!");
            return;
        }


        String data = args[0]; //"/cs/studres/CS1003/Practicals/P4/Tests/data" 
        String searchTerm = args[1]; //a phrase

        /**
         * if the argument is not double it would catch an error
         * and prints an appropriate message
         */
        Double similarity;
        try{
            similarity = Double.parseDouble(args[2]);
        }catch(NumberFormatException e){
            System.out.println("The similarity index you put must be a fraction between 0 and 1.");
            return;
        }

        if (similarity < 0 || similarity > 1){
            System.out.println("The similarity index you put must be a fraction between 0 and 1.");
            return;
        }
        /**
         * find the legnth of the search term
         */
        int termLength = searchTerm.split(" ").length;
        

        /**
         * name of the Spark and the cluster
         */
        String appName = "HelloSpark";
        String cluster = "local[*]";

        SparkConf conf = new SparkConf()
                            .setAppName(appName)
                            .setMaster(cluster);        

        /**
         * connection to Spark
         */
        JavaSparkContext sc = new JavaSparkContext(conf);

        /**
         * calculating the bigrams of the search term
         */
        HashSet<String> bigrams = calculateBigrams(searchTerm);
        
        /**
         * Read and saves the files
         */
        JavaPairRDD<String,String> files = sc.wholeTextFiles(data);

        /**
         * Finds the phrases with the same length as the search term
         */
        JavaRDD<String> phrases  = files.flatMap(x -> textSeparator(termLength,x._2()).iterator());

        /**
         * Maps the phrases in a pair with its bigrams
         */
        JavaPairRDD<String,HashSet<String>> bigramsPhrases = phrases
                                            .mapToPair(x -> new Tuple2<String,HashSet<String>>(x,calculateBigrams(x)));
        
        /**
         * Maps the phrases together with its Jaccard index
         */
        JavaPairRDD<String,Double> jaccard = bigramsPhrases
                                            .mapToPair(x -> new Tuple2<String,Double>(x._1(),calcuateJaccard(bigrams,x._2())));

        /**
         * Filters and prints only the phrases with bigger
         * similarity than the given one
         */
        jaccard.filter(x -> x._2() >= similarity).foreach(x -> System.out.println(x._1()));
       




    }


    /**
     * Calculates the bigrams in a phrase
     * @param text takes a phrase
     * @return the bigrams in a HashSet
     */
    static HashSet<String> calculateBigrams(String text){
        HashSet<String> set = new HashSet<String>();
        for(int i = 0; i < text.length()-1; i++){
            set.add(text.substring(i,i+2));

        }
        return set;
    }

    /**
     * Separates the text file into phrases with the length of the 
     */
    static List<String> textSeparator(int termLength, String text){
        text = text.replaceAll("[^a-zA-Z0-9]", " ");
        text = text.toLowerCase();
        String[] splitText = text.split("[ \t\n\r]");

        /**
         * removes the zero-length characters in the array
         */
        splitText = Arrays.stream(splitText).filter(x -> x.length()!= 0).toArray(size -> new String[size]);
        
        List<String> list = new ArrayList<>();

        String string;
      
        for(int i = 0;i < splitText.length - termLength+1;i++){
            string = splitText[i];
            for(int j = 1; j <= termLength - 1; j++){
                string+= " " +  splitText[i+j];
            }
            list.add(string);
        }

        return list;
    }

    /**
     * Calcluates the jaccard index
     * @param bigrams The bigrams of the seacrh term
     * @param bigramsPhrases The bigrams of on of the phrases
     * @return Jaccard similarity
     */
    public static double calcuateJaccard(HashSet<String> bigrams,HashSet<String> bigramsPhrases){
        HashSet<String> intersection = new HashSet<String>(bigrams);
        HashSet<String> union = new HashSet<String>(bigrams);
        intersection.retainAll(bigramsPhrases);
        union.addAll(bigramsPhrases);
        return ((double)intersection.size())/union.size();

    }
}