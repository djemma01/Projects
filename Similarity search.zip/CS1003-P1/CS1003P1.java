/** 
* Program that calculates the similarity of words using Jaccard Index
*
* @author 200015143
*
* @since February 2020
*/

/**
 * Libraries needed for reading files and using lists and sets
 */
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
public class CS1003P1 {

    static HashSet<String> intersection;
    static HashSet<String> union;
    static float maxSimilarity = 0.0f;
    static float currentSimilarity;
    static String bestMatch;
    public static void main(String[] args) throws Exception {
        /**
         * A check for the right number of arguments
         */
       if(args.length != 2){
            System.out.println("Expected 2 arguments, but got: " + args.length);
            System.out.println("Usage: java CS1003P1 <word_file> <query>");
            return;
        }

        /**
         * Put the words from the file in an ArrayList
         * Catch the exception if the file does not exist
         */
        List<String> lines = new ArrayList<>();
        try{
            lines = Files.readAllLines(Paths.get(args[0]));
        }
        catch(NoSuchFileException e){
            System.out.println("File does not exist: " + args[0]);
            return;
        }

        /**
         * A loop that goes through the ArrayList
         */
        for(String str : lines){
            /**
             * Adding top and tail to the words in the file and the given word
             */
            str = '^' + str + '$';
            intersection = new HashSet<String>(calculateBiagrams('^' + args[1] + '$'));
            union = new HashSet<String>(calculateBiagrams('^' + args[1] + '$'));

            /**
             * calculating the intersection and the union
             */
            intersection.retainAll(calculateBiagrams(str));
            union.addAll(calculateBiagrams(str));

            /**
             * find the current similarity and check if it is bigger 
             * than the maximum similarity to this moment
             */
            currentSimilarity = (float)intersection.size()/union.size();
            if(currentSimilarity > maxSimilarity){
                maxSimilarity = currentSimilarity;
                bestMatch = str;
            }
        }
        /**
         * removing the top and the tail of the words that matches best
         */
        if(bestMatch != null)
            bestMatch = bestMatch.substring(1,bestMatch.length()-1);
        else
            System.out.println("No close matches found");

        /**
         * printing the results
         */
        System.out.println("Result: " + bestMatch);
        System.out.println("Score: " + maxSimilarity);
    }

    /**
     * This method gives the bigrams of a single string
     * @param word the word we choose to make bigrams on
     * @return a set with bigrams
     */
    static HashSet<String> calculateBiagrams(String word){
        HashSet<String> set = new HashSet<String>();
        for(int i = 0; i < word.length()-1; i++){
            set.add(word.substring(i,i+2));

        }
        return set;
    }
}
