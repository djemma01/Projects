/** 
* Program that calculates the similarity of words using Levenshtein distance
*
* @author 200015143
*
* @since February 2020
*/

/**
 * Libraries needed for reading files and using lists and sets
 */
    import java.nio.file.Files;
    import java.nio.file.NoSuchFileException;
    import java.nio.file.Paths;
    import java.util.ArrayList;
    import java.util.List;
    
    public class Levensthein {

    static float maxSimilarity = 0.0f;
    static float currentSimilarity;
    static String bestMatch;
    public static void main(String[] args) throws Exception {
        /**
         * A check for the right number of arguments
         */
        if(args.length != 2){
            System.out.println("Expected 2 arguments, but got: " + args.length);
            System.out.println("Usage: java CS1003P1 <word_file> <query>");
            return;
        }

         /**
         * Putting the words from the file in an ArrayList
         * Attempt to catch and exception if the file does not exist
         */        
        List<String> lines = new ArrayList<>(); 
        try{
            lines = Files.readAllLines(Paths.get(args[0]));
        }
        catch(NoSuchFileException e){
            System.out.println("File does not exist: " + args[0]);
            return;
        }

        /**
         * A loop that goes through the ArrayList
         */
        for(String str : lines){
            /**
             * finding th similarity using the Levenshtein distance
             */
            currentSimilarity = Levenshtein(str,args[1]);

            /**
             * find the current similarity and check if it is bigger 
             * then the maximum similarity to this moment
             */
            if(currentSimilarity > maxSimilarity){
                maxSimilarity = currentSimilarity;
                bestMatch = str;
            }
        }

        /**
         * printing the results
         */
        System.out.println("Result: " + bestMatch);
        System.out.println("Score: " + maxSimilarity);
        
    }

    /**
     * This method finds the Levenshtein distance and use it to print a similarity score
     * @param word1 first word we want to comapre
     * @param word2 second word we want to comapre
     * @return similarity score based on Levenshtein distance
     */
    public static float Levenshtein(String word1, String word2){
        int[][] differences = new int[word1.length()+1][word2.length()+1];
        for(int i = 0; i < word1.length()+1;i++){
            differences[i][0] = i;
        }
        for(int i = 0; i < word2.length()+1;i++){
            differences[0][i] = i;
        }
        for(int i = 1; i < word1.length()+1;i++){
            for(int j = 1; j < word2.length()+1;j++){
                if(word1.charAt(i-1) == word2.charAt(j-1)){
                    differences[i][j] = differences[i-1][j-1];
                }
                else{
                    differences[i][j] = 1 + Math.min(differences[i-1][j],Math.min(differences[i-1][j-1],differences[i][j-1]));
                }
            }
        }

        return 1.0f-(float)differences[word1.length()][word2.length()]/Math.max(word1.length(),word2.length());

    }
}

