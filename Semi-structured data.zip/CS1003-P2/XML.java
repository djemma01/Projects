/**
 * @author 200015143
 * @since February
 * A program that gets Json files from www.omdbapi.com by a movie title
 * and prints the 10 most frequent words in the plot of the 10 requests
 */

 /**
  * Libraries  needed for the program
  */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XML {
    public static void main(String[] args){
        /**
         * Checks if we have 3 arguments and prints an approriate message if not
         */
        if(args.length != 3){
            System.err.println("Expected 3 arguments, but got: " + args.length);
            System.err.println("Usage: java CS1003P2 <source> <stopwords_file> <search term>");
            return;
        }
        String apikey = "9024a7d5"; // Apikey taken by registering in the www.omdbapi.com
        String source = args[0]; // Online and chache are possible options
        String stopWordsFile = args[1]; // File with frequnetly used words
        HashSet<String> stopWords = new HashSet<>();
        String title = args[2]; // Request for the movie
        title = title.replace(" ", "+");

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db;
        /**
         * Exception handling
         */
        try{
            db = dbf.newDocumentBuilder();
        }catch(ParserConfigurationException e){
            System.out.println("Unexpected error occured!");
            return;
        }

        /**
         * Reads the file if it exist
         */
        Scanner reader;
        try{
            reader = new Scanner(new File(stopWordsFile));
        }
        catch(FileNotFoundException e){
            System.err.println("File does not exist: " + stopWordsFile);
            return;
        }
        while(reader.hasNextLine()){
            stopWords.add(reader.nextLine());
        }

        /**
         * When the source is online
         */
        if (source.equals("online")) {
            String plotMerge = "";
            String XMLTitle = "https://www.omdbapi.com/?apikey=" + apikey + "&r=xml&s=" + title;
            Document document;
            try{
                document = db.parse(XMLTitle);
            }catch(SAXException | IOException e){
                System.out.println("Invalid request!");
                return;
            }
            NodeList nodeList = document.getElementsByTagName("result");
            /**
             * Iteretas through the result tag and get the movies ID
             */
            for(int i=0; i < nodeList.getLength(); i++) {
                String imdbID = nodeList.item(i).getAttributes().getNamedItem("imdbID").getNodeValue();
                String XMLID = "https://www.omdbapi.com/?apikey=" + apikey + "&r=xml&i=" + imdbID;
                try {
                    document = db.parse(XMLID);
                } catch (SAXException | IOException e) {
                    System.out.println("Movie with ID: " + imdbID + " could not be found!");
                    return;
                }

                NodeList nodelist2 = document.getElementsByTagName("movie");
                String plot = nodelist2.item(0).getAttributes().getNamedItem("plot").getNodeValue();
                String movie = nodelist2.item(0).getAttributes().getNamedItem("title").getNodeValue();
                System.out.println("Movie " + (i+1));
                System.out.println("Title: " + movie);
                System.out.println("Plot: " + plot + "\n");

                // merges plot of each movie in a single String
                plotMerge = plotMerge + " " + plot;
            }

            /**
             * Stores the sorted LinkedHashMap
             */
            LinkedHashMap<String,Integer> sortedWords = wordCount(stopWords, plotMerge);
            if(sortedWords.size() == 0){
                System.out.println("No plot/non-stopwords words found!");
                return;
            }
            int counter = 0;
            System.out.println("Most frequent words in the plot fields:\n");
            for(String word : sortedWords.keySet()){
                System.out.println("\t" + sortedWords.get(word) + "\t" + word);
                counter ++;
                if(counter == 10){
                    break;
                }
            }

        }else{
            System.out.println("Invalid source!");
            System.out.println("Source can be only 'online'");
            return;
        }
    }

     /**
     * @param stopwords to eliminate some frequntly used words
     * @param plotMerge to check the words
     * @return A sorted HashMap
     */
    public static LinkedHashMap<String,Integer> wordCount(HashSet<String> stopwords, String plotMerge){
        HashMap<String,Integer> words = new HashMap<>();
        plotMerge = plotMerge.replaceAll("[^a-zA-Z0-9]", " ");
        plotMerge = plotMerge.toLowerCase();
        String[] plot = plotMerge.split("[ \t\n\r]");

        for(String word : plot){
            if(word.length() > 1 && !stopwords.contains(word)){
                if(words.containsKey(word)){
                    words.put(word, words.get(word)+1);
                }
                else{
                    words.put(word,1);
                }
            }
        }

        return sortHashMap(words);
        
    }

    /**
     * @param toSort unsorted HashMap
     * @return sorted HashMap
     * Influenced by https://www.geeksforgeeks.org/sorting-a-hashmap-according-to-values/
     * and updated to also compare the keys if the values are equal to sort it alphabetically
     */
    public static LinkedHashMap<String,Integer> sortHashMap(HashMap<String,Integer> toSort){

        LinkedList<Map.Entry<String, Integer>> list = new LinkedList<>(toSort.entrySet());
        
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>(){
            @Override
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2){
                if(o1.getValue() == o2.getValue()){
                    return o1.getKey().compareTo(o2.getKey());
                }
                return o2.getValue() - o1.getValue();
            }
        });

        LinkedHashMap<String, Integer> sortedMap = new LinkedHashMap<>();

        for(Map.Entry<String, Integer> entry: list){
            sortedMap.put(entry.getKey(), entry.getValue());
        }

        return sortedMap;
    }
}
