/**
 * @author 200015143
 * @since February
 * A program that gets Json files from www.omdbapi.com by a movie title
 * and prints the 10 most frequent words in the plot of the 10 requests
 */

 /**
  * Libraries  needed for the program
  */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;

/**
 * http://stleary.github.io/JSON-java/index.html
 * Libraries for parsing JSON files
 */
import org.json.JSONException;
import org.json.JSONObject;

public class CS1003P2 {
    public static void main(String[] args) {

        /**
         * Checks if we have 3 arguments and prints an approriate message if not
         */
        if (args.length != 3) {
            System.err.println("Expected 3 arguments, but got: " + args.length);
            System.err.println("Usage: java CS1003P2 <source> <stopwords_file> <search term>");
            return;
        }
        String apikey = "9024a7d5"; // Apikey taken by registering in the www.omdbapi.com
        String source = args[0]; // Online and chache are possible options
        String stopWordsFile = args[1]; // File with frequnetly used words
        HashSet<String> stopWords = new HashSet<>();
        String title = args[2]; // Request for the movie

        title = title.replace(" ", "+"); // intervals exchange

        /**
         * Checks whether the source is valid
         */
        if (!source.equals("online") && !source.equals("cache")) {
            System.err.println("Invalid source!");
            System.err.println("Source can only be 'online' or 'cache'");
            return;
        }

        /**
         * Reads the file if it exist
         */
        Scanner reader;
        try {
            reader = new Scanner(new File(stopWordsFile));
        } catch (FileNotFoundException e) {
            System.err.println("File does not exist: " + stopWordsFile);
            return;
        }

        /**
         * Add all lines of the file in a HashSet
         */
        while (reader.hasNextLine()) {
            stopWords.add(reader.nextLine());
        }

        /**
         * When the source is online
         */
        if (source.equals("online")) {
            String plotMerge = "";

            String jsonTitle;
            try {
                jsonTitle = getTitleJson(apikey, "s=" + title);
            } catch (IOException e1) {
                System.out.println("Invalid title!");
                return;
            }
            JSONObject objTitle = new JSONObject(jsonTitle); // Creates JSONObject by a string

            /**
             * Iteretas through the first then key-value pairs and get the movies ID
             */
            for (int i = 0; i < 10; i++) {
                String imdbID = "";
                try {
                    imdbID = objTitle.getJSONArray("Search").getJSONObject(i).getString("imdbID");
                } catch (JSONException e) {
                    if (i == 0) {
                        System.out.println("No result found!");
                        return;
                    } else {
                        break;
                    }
                }
                // merges plot of each movie in a single String
                try {
                    plotMerge = plotMerge + " " + extractDetails(i, getImdbIDJson(apikey, imdbID));
                } catch (IOException e) {
                    System.out.println("Unexpected error occured");
                    return;
                }
            }

            /**
             * Stores the sorted LinkedHashMap
             */
            LinkedHashMap<String, Integer> sortedWords = wordCount(stopWords, plotMerge);
            int counter = 0; // Counter to get just the first 10 words
            if (sortedWords.size() == 0) {
                System.out.println("No plot found!"); // If there is no plot
            } else {
                System.out.println("Most frequent words in the plot fields:\n");

                /**
                 * Prints top 10 most frequent words
                 */
                for (String word : sortedWords.keySet()) {
                    System.out.println("\t" + sortedWords.get(word) + "\t" + word);
                    counter++;
                    if (counter == 10) {
                        break;
                    }
                }
            }

        }

        /**
         * When the source is cache
         */
        if (source.equals("cache")) {
            /**
             * Creates the names of the files in the cache
             */
            String request = "https://www.omdbapi.com/?r=json&s=" + title;
            String filepath;
            try {
                filepath = URLEncoder.encode(request, "UTF-8") + ".json";
            } catch (UnsupportedEncodingException e) {
                System.out.println("Incorrect URL encoding");
                return;
            }
            filepath = "/cs/studres/CS1003/Practicals/P2/Tests/cachedir/" + filepath;

            try {
                reader = new Scanner(new File(filepath));
            } catch (FileNotFoundException e2) {
                System.err.println("The file does not exist: " + filepath);
                return;
            }
            String line = "";
            while(reader.hasNextLine()){
                line = line + reader.nextLine();
            }

            JSONObject objTitle = new JSONObject(line); //Creates JSONObject by a single String
            String plotMerge = "";
            for(int i = 0; i < 10; i++){
                String imdbID = objTitle.getJSONArray("Search").getJSONObject(i).getString("imdbID");

                request = "https://www.omdbapi.com/?r=json&i=" + imdbID;
                try {
                    filepath = URLEncoder.encode(request, "UTF-8") + ".json";
                } catch (UnsupportedEncodingException e1) {
                    System.out.println("Invalid URL encoding");
                }
                filepath = "/cs/studres/CS1003/Practicals/P2/Tests/cachedir/" + filepath;

                try {
                    reader = new Scanner(new File(filepath));
                } catch (FileNotFoundException e) {
                    System.err.println("The file does not exist: " + filepath);
                    return;
                }
                line = "";
                while(reader.hasNextLine()){
                    line = line + reader.nextLine();
                }

                plotMerge = plotMerge + " " + extractDetails(i, line);
            }
            LinkedHashMap<String,Integer> sortedWords = wordCount(stopWords, plotMerge);
            int counter = 0;
            System.out.println("Most frequent words in the plot fields:\n");
            for(String word : sortedWords.keySet()){
                System.out.println("\t" + sortedWords.get(word) + "\t" + word);
                counter ++;
                if(counter == 10){
                    break;
                }
            }
        }

    }

    /**
     * @param movieCounter keeps the index of the current movie
     * @param jsonFile to read from
     * @return the plot of the current movie
     * Prints the details of the movie
     */
    public static String extractDetails(int movieCounter, String jsonFile){
        JSONObject objID = new JSONObject(jsonFile);
        String plot = objID.getString("Plot");
        String movie = objID.getString("Title");
        System.out.println("Movie " + (movieCounter + 1));
        System.out.println("Title: " + movie);
        System.out.println("Plot: " + plot + "\n");
        return plot;
    }
    
    /**
     * @param apikey 9024a7d5
     * @param title to take the JSON file
     * @return a JSON file in a String
     */
    public static String getTitleJson(String apikey, String title) throws IOException {
        String urlAddress = "https://www.omdbapi.com/?apikey=" + apikey + "&r=json&" + title;
        URL url = new URL(urlAddress);
        URLConnection connection = url.openConnection();
        Scanner reader = new Scanner(connection.getInputStream());
        String line ="";
        while(reader.hasNextLine()){
            line = line + reader.nextLine();
        }
        reader.close();
        return line;
    }

    /**
     * @param apikey 9024a7d5
     * @param imdbID to create a JSON file
     * @return a JSON file in a String
     */
    public static String getImdbIDJson(String apikey,String imdbID) throws IOException {
        imdbID = "i=" + imdbID;
        return getTitleJson(apikey, imdbID);
    }

    /**
     * @param stopwords to eliminate some frequntly used words
     * @param plotMerge to check the words
     * @return A sorted HashMap
     */
    public static LinkedHashMap<String,Integer> wordCount(HashSet<String> stopwords, String plotMerge){
        HashMap<String,Integer> words = new HashMap<>();
        plotMerge = plotMerge.replaceAll("[^a-zA-Z0-9]", " ");
        plotMerge = plotMerge.toLowerCase();
        String[] plot = plotMerge.split("[ \t\n\r]");

        for(String word : plot){
            if(word.length() > 1 && !stopwords.contains(word)){
                if(words.containsKey(word)){
                    words.put(word, words.get(word)+1);
                }
                else{
                    words.put(word,1);
                }
            }
        }

        return sortHashMap(words);
        
    }
    /**
     * @param toSort unsorted HashMap
     * @return sorted HashMap
     * Influenced by https://www.geeksforgeeks.org/sorting-a-hashmap-according-to-values/
     * and updated to also compare the keys if the values are equal to sort it alphabetically
     */
    public static LinkedHashMap<String,Integer> sortHashMap(HashMap<String,Integer> toSort){

        LinkedList<Map.Entry<String, Integer>> list = new LinkedList<>(toSort.entrySet());
        
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>(){
            @Override
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2){
                if(o1.getValue() == o2.getValue()){
                    return o1.getKey().compareTo(o2.getKey());
                }
                return o2.getValue() - o1.getValue();
            }
        });

        LinkedHashMap<String, Integer> sortedMap = new LinkedHashMap<>();

        for(Map.Entry<String, Integer> entry: list){
            sortedMap.put(entry.getKey(), entry.getValue());
        }

        return sortedMap;
    }



}
