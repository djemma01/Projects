/**
 * class that extends Passenger class
 */
public class PremiumPassenger extends Passenger {

    //construcotr of the class
    public PremiumPassenger(String name, int number){
        super(name, number);
    }

    /**
     * extended version of the method in class passenger
     */
    @Override
    public void activitySignUp(Activity activity){
        if(activity.getCapacity() > 0){
            for(int i = 0; i < getActivities().size(); i++){
                if(getActivities().get(i).getDestination() == activity.getDestination()){
                    System.out.println("The passenger has already signed up for an activity on this destination");
                    return;
                }
            }
            addActivity(activity);
            activity.addPassenger();
        }
        else{
            System.out.println("The activity has reached its maximum capaxity. " + this.getName() + " can not sign up.");
        }
    }
}
