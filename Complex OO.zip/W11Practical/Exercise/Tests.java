import java.util.ArrayList;
/**
 * class that allows to implement and test the solution
 */
public class Tests {
    /**
     * stars of the theather shows
     */
    Star star1 = new Star("Pierre Boulanger","Prince Hamlet");
    Star star2 = new Star("Marie-France","Ophelia");
    Star star3 = new Star("Daisy Ridley","Juliet");
    Star star4 = new Star("Freddie Highmore","Romeo");

    /**
     * lists of stars in a play
     */
    ArrayList<Star> stars1 = new ArrayList<>();
    ArrayList<Star> stars2 = new ArrayList<>();

    /**
     * acitvities
     */
    Activity activity1 = new TheatherShow("Hamlet","Interpretation of Shakespeare's drama", 15, 2, stars1);
    Activity activity2 = new TheatherShow("Romeo and Juliet","Interpretation of Shakespeare's drama", 15, 2, stars2);
    Activity activity3 = new WalkingTour("Walking tour of Paris",
                "The tour continues for 3 hours", 50, 15, 10);
    Activity activity4 = new WalkingTour("Walking tour of Amsterdam",
                "The tour continues for 4 hours", 30, 25, 15);
    Activity activity5 = new AttractionVisit("Louver visit",
                "The cost includes a bus from Le Harve to Paris", 20, 3);
    Activity activity6 = new AttractionVisit("Koninklijk Paleis",
                "The tour has a professional guide", 15, 4);

    /**
     * list of activities 
     */
    ArrayList<Activity> activities1 = new ArrayList<>();
    ArrayList<Activity> activities2 = new ArrayList<>();

    
    /**
     * passengers
     */
    Passenger passenger1 = new StandartPassenger("Arina Ruseva", 23453, 15);
    Passenger passenger2 = new SeniorPassenger("Annie Encheva", 23563, 50);
    Passenger passenger3 = new PremiumPassenger("Ivo Petrov", 24269);
    
    /**
     * list of passengers
     */
    ArrayList<Passenger> passengers = new ArrayList<>();
    
    /**
     * destinations
     */
    Destination destination1;
    Destination destination2;

    /**
     * list of destinations
     */
    ArrayList<Destination> destinations1 = new ArrayList<>();
    ArrayList<Destination> destinations2 = new ArrayList<>();

    Cabin cabin1 = new Cabin("1A");
    Cabin cabin2 = new Cabin("2A");
    Cabin cabin3 = new PremiumCabin("1B");
    Cabin cabin4 = new PremiumCabin("2B");
    ArrayList<Cabin> cabins1 = new ArrayList<>();
    ArrayList<Cabin> cabins2 = new ArrayList<>();

    /**
     * declaration and initialization of the cruise ship
     */
    Ship ship1;
    Ship ship2;
    public Tests(){
        stars1.add(star1);
        stars1.add(star2);
        stars2.add(star3);
        stars2.add(star4);

        activities1.add(activity2);
        activities1.add(activity4);
        activities1.add(activity6);
        activities2.add(activity1);
        activities2.add(activity3);
        activities2.add(activity5);

        cabins1.add(cabin1);
        cabins2.add(cabin2);
        cabins1.add(cabin3);
        cabins2.add(cabin4);


        ship1 = new Ship("Titanic", 20, cabins1, destinations1);
        ship2 = new Ship("Diamond Princess", 15, cabins2, destinations2);

        destination1 = new Destination("Amsterdam", activities1);
        destination2 = new Destination("Paris", activities2);

        destinations1.add(destination1);
        destinations2.add(destination2);
        
        
    }
    
    /**
     * This scenario show what is happening when we try to a second passenger in the same cabin.
     */
    public void scenario1() {
        System.out.println("SCENARIO 1:\n\n");
        cabin1.addPasenger(passenger1);
        cabin1.addPasenger(passenger2);
        cabin3.addPasenger(passenger3);
        ship1.printDetails();
    }

    /**
     * This scenario represents what happens if you try to put a non-premium passenger in a premium cabin
     */
    public void scenario2() {
        System.out.println("\n\nSCENARIO 2:\n\n");
        System.out.println("\nWhat happens when you try to put non-premium passenger in a premium cabin:\n");
        cabin4.addPasenger(passenger1);
        System.out.println(cabin4);
       
    }

    /**
     * This scenario show that we are able to print the history of the cruise ships
     */
    public void scenario3() {
        System.out.println("\n\nSCENARIO 3:\n\n");
        cabin3.addPasenger(passenger3);
        passenger3.activitySignUp(activity2);
        cabin4.addPasenger(passenger3);
        passenger3.activitySignUp(activity1);
        passenger3.printShipHistory();
    }
}
