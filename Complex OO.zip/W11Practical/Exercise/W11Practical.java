/** 
* Program that maintains a cruise ship and its itenerary and passengers
*
* @author 200015143
*
* @since Nov 2020
*/
public class W11Practical {
    public static void main(String[] args) throws Exception {
        Tests tests1 = new Tests();
        Tests tests2 = new Tests();
        Tests tests3 = new Tests();
        tests1.scenario1();
        tests2.scenario2();
        tests3.scenario3();
    }
}
