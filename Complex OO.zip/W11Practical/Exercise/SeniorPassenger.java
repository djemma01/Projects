/**
 * class that extends StanderPassenger
 */
public class SeniorPassenger extends StandartPassenger {
    /**
     * a discount the senior passenger has
     */
    private static final double DISCOUNT = 0.1;

    /**
     * contructor of the class
     * @param name name of the passenger
     * @param number indetification nnumber of the passenger
     * @param balance balance of the passenger
     */
    SeniorPassenger(String name, int number, double balance){
        super(name, number, balance);
    }

    /**
     * getter for the discount
     * @return 10% discout
     */
    public static double getDiscount() {
        return DISCOUNT;
    }

    /**
     * extended method that sign up a passenger for an acitvity
     */
   @Override
   public void activitySignUp(Activity activity) {
    if(super.getBalance() >= activity.getCost()){
        if(activity.getCapacity() > 0){
            for(int i = 0; i < getActivities().size(); i++){
                if(getActivities().get(i).getDestination() == activity.getDestination()){
                    System.out.println("The passenger has already signed up for an activity on this destination");
                    return;
                }
            }
            addActivity(activity);
            activity.addPassenger();
            deductCost(activity.getCost()*(1-DISCOUNT));
        }
        else{
            System.out.println("The activity has reached its maximum capaxity." + this.getName() + " can not sign up.");
        }
    }
    else{
        System.out.println("The passenger does not have enough balance to pay.");
    }
   }
}
