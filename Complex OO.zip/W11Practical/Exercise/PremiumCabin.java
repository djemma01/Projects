/**
 * This class represents premium cabin
 */
public class PremiumCabin extends Cabin {
    
    public PremiumCabin(String name){
        super(name);
    }

    @Override
    public void addPasenger(Passenger passenger) {
        if(passenger instanceof PremiumPassenger)
            super.addPasenger(passenger);
        else
            System.out.println("You cannot put non-premium passengers in a premium cabin!");
    }
}
