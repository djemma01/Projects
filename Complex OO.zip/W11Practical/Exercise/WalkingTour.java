/**
 * class that extends Activity, represents walkin tour
 */
public class WalkingTour extends Activity {
    private double distance;

    /**
     * constructor
     * @param name name of the activity
     * @param description description of the activity
     * @param cost cost of the activity
     * @param capacity capacity of the activity
     * @param distance distance of the walking tour
     */
    public WalkingTour(String name, String description, double cost, int capacity, double distance){
        super(name, description, cost, capacity);
        setDistance(distance);
        
    }

    /**
     * setter for the walking distance
     * @param distance
     */
    public void setDistance(double distance) {
        if(distance > 0)
            this.distance = distance;
    }

    /**
     * getter for walking distance
     * @return
     */
    public double getDistance() {
        return distance;
    }

    /**
     * Method that allows us to print details of the class
     */
    @Override
    public String toString() {
        return (super.toString() + "\nDistance: " + distance);
    }
}
