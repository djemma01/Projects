/**
 * This class represents a standart cabin
 */
public class Cabin {
    /**
     * Cabin's attributes
     */
    private String name;
    private Passenger passenger;

    /**
     * an attribute to store which ship it belongs to
     */
    private Ship ship;

    /**
     * constructor
     * @param name name of the cabin
     */
    public Cabin(String name){
        this.name = name;
    }

    /**
     * setter for thr name
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * getter for the name
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * setter for the ship
     * @param ship the cabin belongs to this 
     */
    public void setShip(Ship ship) {
        this.ship = ship;
    }

    /**
     * getter for the ship
     * @return
     */
    public Ship getShip() {
        return ship;
    }

    /**
     * a method that adds a passenger in the cabin if it is free
     * it also adds the ship into the passenger's history
     * @param passenger
     */
    public void addPasenger(Passenger passenger){
        if(this.passenger == null){
            this.passenger = passenger;
            this.passenger.newCruise(ship);
        }
        else
            System.out.println("There is already a passenger in this cabin");
    }

    /**
     * getter for the passenger
     * @return
     */
    public Passenger getPassenger() {
        return passenger;
    }

   

    /**
     * a method Method that allows us to print details of the class
     */
    @Override
    public String toString() {
        if(passenger == null){
            return ("\nCabin's name: " + name + "\nCabin is unoccupied");
        }
        return ("\nCabin's name: " + name + "\nPassenger in the cabin: " + passenger);
    }
}
