/**
 * class that extends activity
 */
public class AttractionVisit extends Activity{
    
    //constructor of the class
    public AttractionVisit(String name, String description, double cost, int capacity){
        super(name, description, cost, capacity);
    }
}
