
/**
 * A class that represents the satrs in a play
 */
public class Star {
    private String actorName;
    private String characterName;

    /**
     * construcotr
     * @param actorName name of the actor
     * @param characterName name of the actor's character
     */
    public Star(String actorName, String characterName){
        this.actorName = actorName;
        this.characterName = characterName;
    }

    /**
     * setter for the actor's name
     * @param actorName
     */
    public void setActorName(String actorName) {
        this.actorName = actorName;
    }

    /**
     * getter for the actor's name
     * @return
     */
    public String getActorName() {
        return actorName;
    }

    /**
     * setter for the character's name
     * @param characterName
     */
    public void setCharacterName(String characterName) {
        this.characterName = characterName;
    }

    /**
     * getter for the character's name
     * @return
     */
    public String getCharacterName() {
        return characterName;
    }

    /**
     * Method that allows us to print details of the class
     */
    @Override
    public String toString() {
        return ("\nActor's name: " + actorName + "  Character's name: " + characterName);
    }

}
