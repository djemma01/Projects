import java.util.ArrayList;
/**
 * Class that extends Activity
 */
public class TheatherShow extends Activity {
    private  ArrayList<Star> stars = new ArrayList<>();

    /**
     * Constructor
     * @param name the name of the play
     * @param description the description of the play
     * @param cost the cost in pounds
     * @param capacity capacity of the play
     * @param stars list of actors and their characters
     */
    public TheatherShow(String name, String description, double cost, int capacity, ArrayList<Star> stars){
        super(name, description, cost, capacity);
        this.stars = stars;
    }
    
    /**
     * setter for the list of stars
     * @param stars
     */
    public void setStar(ArrayList<Star> stars) {
        this.stars = stars;
    }
    /**
     * getter for the list of stars
     * @return
     */
    public ArrayList<Star> getStar() {
        return stars;
    }

    /**
     * Method that allows us to print details of the class
     */
    @Override
    public String toString() {
        return (super.toString() + "\nStars: " + stars).replace("[", " ").replace("]", " ").replace(",", " ");
    }
}
