import java.util.ArrayList;
import java.util.HashMap;
/**
 * class that represents a passenger
 */
public abstract class Passenger {
    /**
     * attribute of the class
     */
    private String name;
    private int number;
    protected ArrayList<Activity> activities = new ArrayList<>();
    private HashMap<Ship,ArrayList<Activity>> ships = new HashMap<>();
    

    /**
     * Constructor of the class
     * @param name the name of the passenger
     * @param number specail indetification number
     */
    public Passenger(String name, int number){
        this.name = name;
        setNumber(number);
    }

    /**
     * setter for the name of the passenger
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * getter for the name
     * @return name of the passenger
     */
    public String getName() {
        return name;
    }

    /**
     * setter for the indetification number
     * @param number 
     */
    public void setNumber(int number) {
        if(number > 0)
            this.number = number;
    }

    /**
     * getter for the special number
     * @return number
     */
    public int getNumber() {
        return number;
    }

    /**
     * methods that add and activity to the list of activities
     * @param activity 
     */
    public void addActivity(Activity activity){
        activities.add(activity);
    }

    /**
     * getter for the list of activities
     * @return
     */
    public ArrayList<Activity> getActivities() {
        return activities;
    }
    
    /**
     * 
     * @param ship
     */
    public void newCruise(Ship ship){
        activities = new ArrayList<>();
        ships.put(ship,activities);
    }

    /**
     * a getter for the HashMap
     * @return
     */
    public HashMap<Ship, ArrayList<Activity>> getShips() {
        return ships;
    }

    /**
     * empty method that allow passengers to sign uo for an acitivity
     * this is extended in the other passenger classes
     * @param activity
     */
    public abstract void activitySignUp(Activity activity);

    /**
     * Method that allows us to print details of the class
     */
    @Override
    public String toString() {
        return ("\nName: " + name + "\nPassenger number: " + number + "\nList of activities: " +
        activities).replace("[", " ").replace("]", " ").replace(",", " "); 
    }

    /**
     * Method that prints details of the class
     */
    public void printDetails(){
        System.out.println("\nName: " + name);
        System.out.println("Passenger number: " + number);
        System.out.println("List of activities: " + activities);
    }

    /**
     * Method that print the passenger's history
     */
    public void printShipHistory(){
        for (Ship i : ships.keySet()){
            System.out.println("\nName of Cruise: " + i.getName());;
            for(Activity j : ships.get(i)){
                
                System.out.println("\nActivities: \n"+ j);
                
            }
        }
    }
}
