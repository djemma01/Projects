import java.util.ArrayList;
/**
 * class that represents the destination details
 */
public class Destination {
    /**
     * atributes of the class
     */
    private String name;
    private ArrayList<Activity> activities = new ArrayList<>();

    /**
     * Constructor of the class
     * @param name name of the destination
     * @param activities list of activities
     */
    public Destination(String name, ArrayList<Activity> activities){
        this.name = name;
        this.activities = activities;
        for(Activity i : activities){
            i.setDestination(this);
        }
    }

    /**
     * setter for the name
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * getter for the name
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * setter for the list of activities
     * @param activities a list of activities
     */
    public void setActivities(ArrayList<Activity>  activities) {
        this.activities = activities;
    }

    /**
     * getter for the list of activities
     * @return a list of activities
     */
    public ArrayList<Activity>  getActivities() {
        return activities;
    }

    /**
     * Method that allows us to print details of the class
     */
    @Override
    public String toString() {
        return ("Name: " + name + "\n\nACTIVITIES:\n " + activities).replace("[", " ").replace("]", " ").replace(",", " ");
    }

    /**
     * methods that prints all available activities on the destination
     */
    public void printAvailableActivities(){
        for(Activity i:activities){
            i.printAvailableActivities();
        }
    }
}
