import java.util.ArrayList;

/**
 * Class that represents a cruise ship
 */
public class Ship {
    /**
     * attributes of the class
     */
    private String name;
    private int capacity;
    private ArrayList<Passenger> passengers = new ArrayList<>();
    private ArrayList<Destination> destinations = new ArrayList<>();

    /**
     * Constructor of the class
     * @param name name of the ship
     * @param capacity capacity of the ship
     * @param passengers a list of passengers
     * @param destinations a list of destinations
     */
    public Ship(String name, int capacity, ArrayList<Passenger> passengers, ArrayList<Destination> destinations){
        this.name = name;
        setCapacity(capacity);
        this.passengers = passengers;
        this.destinations = destinations;
    }

    /**
     * setter for the name of the ship
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * getter for the name
     * @return name of the ship
     */
    public String getName() {
        return name;
    }

    /**
     * setter for the capacity
     * @param capacity
     */
    public void setCapacity(int capacity) {
        if(capacity > 0)
            this.capacity = capacity;
    }

    /**
     * getter for the capacity
     * @return
     */
    public int getCapacity() {
        return capacity;
    }

    /**
     * setter for the list of passengers
     * @param passengers
     */
    public void setPassengers(ArrayList<Passenger> passengers) {
        this.passengers = passengers;
    }

    /**
     * getter for the list of passengers
     * @return
     */
    public ArrayList<Passenger> getPassenger() {
        return passengers;
    }

    /**
     * setter for the list of destinations
     * @param destinations
     */
    public void setDestinations(ArrayList<Destination> destinations) {
        this.destinations = destinations;
    }

    /**
     * getter for the destinations
     * @return
     */
    public ArrayList<Destination> getDestination() {
        return destinations;
    }

    /**
     * Method that prints details of the class
     */
    public void printDetails(){
        System.out.println("CRUISE SHIP:\n");
        System.out.println("Name: " + name);
        System.out.println("Capacity: " + capacity);
        System.out.println("List of passengers:\n");
        for(int i=0; i < passengers.size(); i++){
            System.out.println("\n" + (i+1) + ": " + passengers.get(i));
        }
        System.out.println("\nList of destinations:\n");
        for(int i=0; i < destinations.size(); i++){
            System.out.println("\n" + (i+1) + ": " + destinations.get(i));
        }
    }
}