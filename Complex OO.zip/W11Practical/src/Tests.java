import java.util.ArrayList;
/**
 * class that allows to implement and test the solution
 */
public class Tests {
    /**
     * stars of the theather shows
     */
    Star star1 = new Star("Pierre Boulanger","Prince Hamlet");
    Star star2 = new Star("Marie-France","Ophelia");
    Star star3 = new Star("Daisy Ridley","Juliet");
    Star star4 = new Star("Freddie Highmore","Romeo");

    /**
     * lists of stars in a play
     */
    ArrayList<Star> stars1 = new ArrayList<>();
    ArrayList<Star> stars2 = new ArrayList<>();

    /**
     * acitvities
     */
    Activity activity1 = new TheatherShow("Hamlet","Interpretation of Shakespeare's drama", 15, 2, stars1);
    Activity activity2 = new TheatherShow("Romeo and Juliet","Interpretation of Shakespeare's drama", 15, 2, stars2);
    Activity activity3 = new WalkingTour("Walking tour of Paris",
                "The tour continues for 3 hours", 50, 15, 10);
    Activity activity4 = new WalkingTour("Walking tour of Amsterdam",
                "The tour continues for 4 hours", 30, 25, 15);
    Activity activity5 = new AttractionVisit("Louver visit",
                "The cost includes a bus from Le Harve to Paris", 20, 3);
    Activity activity6 = new AttractionVisit("Koninklijk Paleis",
                "The tour has a professional guide", 15, 4);

    /**
     * list of activities 
     */
    ArrayList<Activity> activities1 = new ArrayList<>();
    ArrayList<Activity> activities2 = new ArrayList<>();

    
    /**
     * passengers
     */
    Passenger passenger1 = new StandartPassenger("Arina Ruseva", 23453, 15);
    Passenger passenger2 = new SeniorPassenger("Annie Encheva", 23563, 50);
    Passenger passenger3 = new PremiumPassenger("Ivo Petrov", 24269);
    
    /**
     * list of passengers
     */
    ArrayList<Passenger> passengers = new ArrayList<>();
    
    /**
     * destinations
     */
    Destination destination1;
    Destination destination2;

    /**
     * list of destinations
     */
    ArrayList<Destination> destinations = new ArrayList<>();

    /**
     * declaration and initialization of the cruise ship
     */
    Ship ship = new Ship("Titanic", 20, passengers, destinations);
    public Tests(){
        stars1.add(star1);
        stars1.add(star2);
        stars2.add(star3);
        stars2.add(star4);
        activities1.add(activity2);
        activities1.add(activity4);
        activities1.add(activity6);
        activities2.add(activity1);
        activities2.add(activity3);
        activities2.add(activity5);

        destination1 = new Destination("Amsterdam", activities1);
        destination2 = new Destination("Paris", activities2);

        passengers.add(passenger1);
        passengers.add(passenger2);
        passengers.add(passenger3);
        destinations.add(destination1);
        destinations.add(destination2);
    }
    
    /**
     * This scenario represents what happens when the passenger does not have 
     * enough balance to pay the cost of the activity 
     */
    public void scenario1() {
        
        System.out.println("SCENARIO 1:\n\n");
        passenger1.activitySignUp(activity3);
        System.out.println(passenger1);

    }

    /**
     * This happens when someone tries to sign up for an activity,
     * which does not have more capacity and prints the available activities
     */
    public void scenario2() {
        System.out.println("\n\nSCENARIO 2:\n\n");
        passenger1.activitySignUp(activity1);
        passenger2.activitySignUp(activity1);
        passenger3.activitySignUp(activity1);
        System.out.println("AVAILABLE ACTIVITIES");
        destination1.printAvailableActivities();
        destination2.printAvailableActivities();
    }

    /**
     *This scenario prints a ship and its passengers and itinerary and show what happens if a passenger 
     * sign up on another activity on the same destination
     */
    public void scenario3() {
        System.out.println("\n\nSCENARIO 3:\n\n");
        passenger1.activitySignUp(activity1);
        passenger2.activitySignUp(activity1);
        passenger2.activitySignUp(activity5);
        passenger3.activitySignUp(activity3);
        passenger3.activitySignUp(activity6);
        ship.printDetails();
    }
}
