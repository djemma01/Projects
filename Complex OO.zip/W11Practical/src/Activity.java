/**
 * Class common for all activities
 */
public abstract class Activity {
    /**
     * Attributes each activity has
     */
    private String name;
    private String description;
    private double cost;
    private int capacity;
    private Destination destination;

    /**
     * Constructor of the class
     * @param name name of the activity
     * @param description description of the acitvity
     * @param cost cost in pounds
     * @param capacity capaciry of the activity
     */
    public Activity(String name, String description, double cost, int capacity){
        this.name = name;
        this.description = description;
        setCost(cost);
        setCapacity(capacity);
    }

    /**
     * setter for the name
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * getter for the name
     * @return name of the activity
     */
    public String getName() {
        return name;
    }

    /**
     * setter for the description
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * getter for the description
     * @return the descripiton
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * Setter for the cost
     * @param cost
     */
    public void setCost(double cost) {
        if(cost >= 0)
            this.cost = cost;
    }

    /**
     * getter for the cost
     * @return cost in pounds
     */
    public double getCost() {
        return cost;
    }

    /**
     * setter for the capacity, should be more then 0
     * @param capacity
     */
    public void setCapacity(int capacity) {
        if(capacity > 0)
            this.capacity = capacity;
    }

    /**
     * getter for the capacity
     * @return capacity of the acitvity
     */
    public int getCapacity() {
        return capacity;
    }

    /**
     * A method that adds a passenger for an acitvity
     */
    public void addPassenger(){
        capacity--;
    }

    /**
     * Setter for the destination
     * @param destination
     */
    public void setDestination(Destination destination) {
        if(this.destination == null)
            this.destination = destination;
    }

    /**
     * getter for the destination
     * @return destination
     */
    public Destination getDestination() {
        return destination;
    }

    /**
     * Method that allows us to print details of the class
     */
    @Override
    public String toString() {
        return ("\n\nName: " + name + "\nDescription: " + description + "\nCost: " + cost +
        "\nCapacity: " + capacity + "\nDestination: " + destination.getName() );
    }

    /**
     * Method that prints details of the class
     */
    public void printDetails(){
        System.out.println("\nName: " + name);
        System.out.println("Description: " + description);
        System.out.println("Cost: " + cost);
        System.out.println("Capacity: " + capacity);
        System.out.println("Destination: " + destination.getName());
    }

    /**
     * method that prints only the activities with available spaces
     */
    public void printAvailableActivities(){
        if(capacity > 0){
            printDetails();
            System.out.println("Available capacity: " + capacity);
        }
    }
    
}
