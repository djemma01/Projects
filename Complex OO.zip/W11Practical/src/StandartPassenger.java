/**
 * class that extends Passenger class
 */
public class StandartPassenger extends Passenger {
    private double balance;

    /**
     * Construcotr
     * @param name name of the passenger
     * @param number indetification number of the passenger
     * @param balance balance of the passenger
     */
    public StandartPassenger(String name, int number, double balance){
        super(name, number);
        this.balance = balance;
    }

    /**
     * setter fot the balance
     * @param balance
     */
    public void setBalance(int balance) {
        this.balance = balance;
    }

    /**
     * getter for the balance
     * @return
     */
    public double getBalance() {
        return balance;
    }

    /**
     * a methods that signs up a passenger for an activity
     */
    @Override
    public void activitySignUp(Activity activity){
        if(balance >= activity.getCost()){
            if(activity.getCapacity() > 0){
                for(int i = 0; i < getActivities().size(); i++){
                    if(getActivities().get(i).getDestination() == activity.getDestination()){
                        System.out.println("The passenger has already signed up for an activity on this destination");
                        return;
                    }
                }
                addActivity(activity);
                activity.addPassenger();
                deductCost(activity.getCost());
            }
            else{
                System.out.println("The activity has reached its maximum capaxity. " + this.getName() + " can not sign up.");
            }
        }
        else{
            System.out.println("The passenger does not have enough balance to sign up for this activity");
        }
    }

    /**
     * a method that deducts a cost from the balance
     * @param cost cost in pounds
     */
    public void deductCost(double cost){
        balance = balance - cost;

    }

    /**
     * Method that allows us to print details of the class
     */
    @Override
    public String toString() {
        return (super.toString() + "\nBalance: £" + balance);
        
    }

    /**
     * Method that prints the details of the class
     */
    @Override
    public void printDetails() {
        super.printDetails();
        System.out.println("Balance: £" + balance);
    }


}
